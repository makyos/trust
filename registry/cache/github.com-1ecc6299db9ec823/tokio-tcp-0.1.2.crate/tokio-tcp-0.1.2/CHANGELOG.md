# 0.1.2 (September 27, 2018)

* Documentation tweaks

# 0.1.1 (August 6, 2018)

* Add `TcpStream::try_clone` (#448)

# 0.1.0 (March 23, 2018)

* Initial release
