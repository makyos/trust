#![feature(test)]

extern crate http;
extern crate test;
extern crate indexmap;
extern crate seahash;
extern crate fnv;

mod basic;
mod vec_map;
