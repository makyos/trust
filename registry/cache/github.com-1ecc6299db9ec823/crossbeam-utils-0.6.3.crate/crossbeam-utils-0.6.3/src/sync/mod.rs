//! Synchronization tools.

mod parker;

pub use self::parker::{Parker, Unparker};
