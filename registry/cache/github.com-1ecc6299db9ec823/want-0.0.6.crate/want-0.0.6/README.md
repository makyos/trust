# Want

A `Future`s channel-like utility to signal when a value is wanted.
