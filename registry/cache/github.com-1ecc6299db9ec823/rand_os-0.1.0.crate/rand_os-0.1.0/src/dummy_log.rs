#[allow(unused)]
macro_rules! trace { ($($x:tt)*) => () }
#[allow(unused)]
macro_rules! debug { ($($x:tt)*) => () }
#[allow(unused)]
macro_rules! info { ($($x:tt)*) => () }
#[allow(unused)]
macro_rules! warn { ($($x:tt)*) => () }
#[allow(unused)]
macro_rules! error { ($($x:tt)*) => () }
