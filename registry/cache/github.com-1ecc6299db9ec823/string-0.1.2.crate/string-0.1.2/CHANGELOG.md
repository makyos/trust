# 0.1.2 (November 21, 2018)

* Implement `DerefMut` and `Display` (#5).
* Implement `from_str` (#7).

# 0.1.1 (July 13, 2018)

* Fix doc gen (#2).

# 0.1.0 (January 11, 2018)

* Initial release.
